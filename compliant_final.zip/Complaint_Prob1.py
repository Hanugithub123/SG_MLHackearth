import numpy as np
import pandas as pd
import re  
import nltk  
 
import pickle  
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
from nltk.stem import WordNetLemmatizer
from nltk import wordpunct_tokenize
from nltk.tokenize import word_tokenize, RegexpTokenizer
import string
from nltk.stem.snowball import SnowballStemmer

from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.feature_extraction.text import TfidfTransformer
from sklearn.feature_extraction.text import TfidfVectorizer


from sklearn.svm import LinearSVC
from sklearn.metrics import accuracy_score, f1_score, confusion_matrix,classification_report

import warnings
warnings.filterwarnings("ignore")
#----------------------------------------------------------------------
def _calculate_languages_ratios(text):
    languages_ratios = {}
    tokens = wordpunct_tokenize(text)
    words = [word.lower() for word in tokens]

    # Compute per language included in nltk number of unique stopwords appearing in analyzed text
    for language in stopwords.fileids():
        stopwords_set = set(stopwords.words(language))
        words_set = set(words)
        common_elements = words_set.intersection(stopwords_set)

        languages_ratios[language] = len(common_elements) # language "score"

    return languages_ratios

def detect_language(text):
    
    ratios = _calculate_languages_ratios(text)
    l={'english':ratios['english'],'french':ratios['french'],'spanish':ratios['spanish']}
    
    most_rated_language = max(l,key=l.get)

    return str(most_rated_language)
#----------------------------------------------------------------------

def tokenize(text):
    return [stemmer.stem(word) for word in tokenizer.tokenize(text.lower())]

#Data cleaning
def data_cleaning(text,lang):
    document = text.lower()    
    stop_words = set(stopwords.words(lang))
    # clean and tokenize document string
    content = document.split()    
    word_list = []
    for i in content:
        if (('http' not in i) and ('@' not in i) and ('<.*?>' not in i) and i.isalnum() and (not i in stop_words)):
            word_list += [i]
        
    return word_list

train = pd.read_csv('train.csv') 
test = pd.read_csv("test.csv")

status =['Closed with non-monetary relief','Closed' ,'Closed with explanation', 'Untimely response','Closed with monetary relief']
def simplify_ComplaintStatus(df):
    df['Complaint-Status'] = df['Complaint-Status'].apply(lambda status: 0 if status == 'Closed with non-monetary relief' else (1 if status == 'Closed' else (2 if status == 
'Closed with explanation' else (3 if status == 'Untimely response' else 4))))
    df['Complaint-Status'] = df['Complaint-Status'].astype(int)
    return df
train = simplify_ComplaintStatus(train)

X, y = train['Consumer-complaint-summary'], train['Complaint-Status']
test_summary = test['Consumer-complaint-summary']
        
def remove_allspecialchar(X):
    documents = []

    for sen in range(0, len(X)):  
        # Remove all the special characters
        document = re.sub(r'\W', ' ', str(X[sen]))

        # remove all single characters
        document = re.sub(r'\s+[a-zA-Z]\s+', ' ', document)
        
        document = re.sub(r'[\d]', ' ', document)
        
        # Remove single characters from the start
        document = re.sub(r'\^[a-zA-Z]\s+', ' ', document) 

        # Substituting multiple spaces with single space
        document = re.sub(r'\s+', ' ', document, flags=re.I)

        # Removing prefixed 'b'
        document = re.sub(r'^b\s+', '', document)

        # Removing '\\n'
        document = re.sub('\\n', '', document)
        
        document =re.sub('\[[^]]*\]', '', document)
        
        
        # Converting to Lowercase
        document = document.lower()
        
        #detect language in the document
        lang=detect_language(document)
        
        stemmer = SnowballStemmer(lang)
        if lang == 'english':
            tokenizer = RegexpTokenizer(r'[a-zA-Z\']+')
        else:
            tokenizer = RegexpTokenizer(r'''\w'|\w+|[^\w\s]''')
            
        document=tokenize(document)
        document = ' '.join(document)
        
        #clearning all the data including stop words, tokenize, stemming words.
        document= data_cleaning(document,lang)
        document = ' '.join(document)
        
        documents.append(document)

    documents = pd.Series(documents)
    
    return documents

train['Consumer-complaint-summary']=remove_allspecialchar(X)
test['Consumer-complaint-summary']=remove_allspecialchar(test_summary)
#train['language']=train['Consumer-complaint-summary'].map(lambda lang:detect_language(lang))


X_train = train['Consumer-complaint-summary']
y_train = train['Complaint-Status']

test_submission = test['Consumer-complaint-summary']

X_train, X_test, y_train, y_test = train_test_split(X_train, y_train, test_size=0.2, random_state=0)


# Instantiate the vectorizer
word_vectorizer = TfidfVectorizer(
    sublinear_tf=True,
    encoding='latin-1', min_df=1, max_df=0.5,
    analyzer='word',
    token_pattern=r'\w{2,}',  #vectorize 2-character words or more
    ngram_range=(1, 2),
    max_features=30000)

# fit and transform on it the training features
word_vectorizer.fit(X_train)

X_train_features = word_vectorizer.transform(X_train).toarray()

#transform the test features to sparse matrix
X_test_features = word_vectorizer.transform(X_test)

submission_features = word_vectorizer.transform(test_submission)


#fit and transform the features in Linear SVC alorigthm for train and test data by splitting and uploading and saving the text classifiers to the drive

lsv=LinearSVC(tol=1e-5)
lsv.fit(X_train_features, y_train)
y_pred = lsv.predict(X_test_features)
print("score: {:.2f}%".format(lsv.score(X_train_features, y_train) * 100))
print("Accuracy: {:.2f}%".format(accuracy_score(y_test, y_pred) * 100))
print("\nF1 Score: {:.2f}".format(f1_score(y_test, y_pred, average='weighted') * 100))
print("\nCOnfusion Matrix:\n", confusion_matrix(y_test, y_pred))
print("\nClassification Report:\n", classification_report(y_test, y_pred))


with open('text_classifier', 'wb') as picklefile:  
    pickle.dump(lsv,picklefile)
print('classifier uploaded completely')


pred = lsv.predict(submission_features)

submission =  pd.DataFrame({ 'Complaint-ID' : test['Complaint-ID'], 'Complaint-Status': list(map(lambda x:status[x],pred)) })
submission.to_csv('submission_pred.csv', index=False)
