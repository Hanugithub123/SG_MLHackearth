import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)
import re
import gensim
from gensim.models import Doc2Vec

import nltk
from nltk.tokenize import RegexpTokenizer
from nltk.corpus import stopwords
from nltk.stem.porter import PorterStemmer
from nltk.stem import WordNetLemmatizer
from string import punctuation

from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score
from sklearn import metrics

import pylab as pl
import matplotlib.pyplot as plt
from sklearn.decomposition import PCA

from bs4 import BeautifulSoup
import contractions
import inflect

import warnings
warnings.filterwarnings("ignore")

train = pd.read_csv('news.csv')
train['text'] =[s.encode('ascii', 'replace').strip()
               for s in train['text'].str.decode('unicode_escape')]

def strip_html(text):
    soup = BeautifulSoup(text, "html.parser")
    return soup.get_text()

def remove_between_square_brackets(text):
    return re.sub('\[[^]]*\]', '', text)

def denoise_text(text):
    text = strip_html(text)
    text = remove_between_square_brackets(text)
    return text

def replace_contractions(text):
    """Replace contractions in string of text"""
    return contractions.fix(text)


#Data cleaning
def data_cleaning(text):
    document = text.lower()    
    # clean and tokenize document string
    content = document.split()    
    word_list = []
    for i in content:
        x = 0
        if (('http' not in i) and ('@' not in i) and ('<.*?>' not in i) and i.isalnum() and (not i in stop_words)):
            word_list += [i]
        
    return word_list 

#Data Pre-processing
def preprocessing(text):    
    # remove numbers
    number_tokens = [re.sub(r'[\d]', ' ', i) for i in text]
    number_tokens = ' '.join(number_tokens).split()
    length_tokens=''
    if len(number_tokens) >1:
        # stem tokens
        #stemmed_tokens = [p_stemmer.stem(i) for i in number_tokens]

        stemmed_tokens = [lemmatizer.lemmatize(word) for word in number_tokens]


        # remove empty
        length_tokens = [i for i in stemmed_tokens if len(i) > 1]
    return length_tokens


LabeledSentence1 = gensim.models.doc2vec.TaggedDocument
all_content = []
texts = []
j=0
tokenizer = RegexpTokenizer(r'\w+')
stop_words = set(stopwords.words('english'))
#p_stemmer = PorterStemmer()
lemmatizer = WordNetLemmatizer()
c=1
unwords =[]
for i in train['text']:
    document = denoise_text(i)
    document = replace_contractions(document)
    document = document.lower()
    document = document.replace('.','. ')

    document = document.replace('?','? ')
    
    #Data cleaning
    clean_content = data_cleaning(document)
    
    #Pre-processing
    processed = preprocessing(clean_content)
    
    #texts.append(' '.join(processed))
    # add tokens to list
    if processed:
        all_content.append(LabeledSentence1(processed,[j]))
        j+=1
    else:
        unwords.append(c)
    c+=1

d2v_model = Doc2Vec(all_content, size =2000, window = 10, min_count =500, workers=7, dm = 1, 
                alpha=0.025, min_alpha=0.001)
d2v_model.train(all_content, total_examples=d2v_model.corpus_count, epochs=10, start_alpha=0.002, end_alpha=-0.016)

pd.DataFrame(d2v_model.docvecs.doctag_syn0).to_csv('./array.txt')


clf = KMeans(n_clusters=8, n_jobs=-1, max_iter=50000, random_state=0)
clf.fit(d2v_model.docvecs.doctag_syn0)
print('Clustering complete')


comment_label = clf.labels_
comment_label = comment_label.astype(np.str)
for i in unwords:
    comment_label=np.insert(comment_label,i-1,'')
    
comment_cluster_df = pd.DataFrame(train)
comment_cluster_df['id']=train['id']
comment_cluster_df['label'] = np.nan
comment_cluster_df['label'] = comment_label
comment_cluster_df = comment_cluster_df.drop(['text','headline'],axis=1)


print('Saving to csv')
comment_cluster_df.to_csv('./output.csv', index=False)




from sklearn.metrics import silhouette_samples, silhouette_score
import matplotlib.pyplot as plt
import matplotlib.cm as cm

X=d2v_model.docvecs.doctag_syn0
range_n_clusters = [2,3,4,5,6,7,8]
#[12,14,16,18,20,22,24,26]

for n_clusters in range_n_clusters:
    # Create a subplot with 1 row and 2 columns
    fig, (ax1, ax2) = plt.subplots(1, 2)
    fig.set_size_inches(18, 7)

    # The 1st subplot is the silhouette plot
    # The silhouette coefficient can range from -1, 1 but in this example all
    # lie within [-0.1, 1]
    ax1.set_xlim([-0.1, 1])
    # The (n_clusters+1)*10 is for inserting blank space between silhouette
    # plots of individual clusters, to demarcate them clearly.
    ax1.set_ylim([0, len(X) + (n_clusters + 1) * 10])

    # Initialize the clusterer with n_clusters value and a random generator
    # seed of 10 for reproducibility.
    clusterer = KMeans(n_clusters=n_clusters, random_state=10)
    cluster_labels = clusterer.fit_predict(X)

    # The silhouette_score gives the average value for all the samples.
    # This gives a perspective into the density and separation of the formed
    # clusters
    silhouette_avg = silhouette_score(X, cluster_labels)
    print("For n_clusters =", n_clusters,
          "The average silhouette_score is :", silhouette_avg)

    # Compute the silhouette scores for each sample
    sample_silhouette_values = silhouette_samples(X, cluster_labels)

    y_lower = 10
    for i in range(n_clusters):
        # Aggregate the silhouette scores for samples belonging to
        # cluster i, and sort them
        ith_cluster_silhouette_values = \
            sample_silhouette_values[cluster_labels == i]

        ith_cluster_silhouette_values.sort()

        size_cluster_i = ith_cluster_silhouette_values.shape[0]
        y_upper = y_lower + size_cluster_i

        color = cm.nipy_spectral(float(i) / n_clusters)
        ax1.fill_betweenx(np.arange(y_lower, y_upper),
                          0, ith_cluster_silhouette_values,
                          facecolor=color, edgecolor=color, alpha=0.7)

        # Label the silhouette plots with their cluster numbers at the middle
        ax1.text(-0.05, y_lower + 0.5 * size_cluster_i, str(i))

        # Compute the new y_lower for next plot
        y_lower = y_upper + 10  # 10 for the 0 samples

    ax1.set_title("The silhouette plot for the various clusters.")
    ax1.set_xlabel("The silhouette coefficient values")
    ax1.set_ylabel("Cluster label")

    # The vertical line for average silhouette score of all the values
    ax1.axvline(x=silhouette_avg, color="red", linestyle="--")

    ax1.set_yticks([])  # Clear the yaxis labels / ticks
    ax1.set_xticks([-0.1, 0, 0.2, 0.4, 0.6, 0.8, 1])

    # 2nd Plot showing the actual clusters formed
    colors = cm.nipy_spectral(cluster_labels.astype(float) / n_clusters)
    ax2.scatter(X[:, 0], X[:, 1], marker='.', s=30, lw=0, alpha=0.7,
                c=colors, edgecolor='k')

    # Labeling the clusters
    centers = clusterer.cluster_centers_
    # Draw white circles at cluster centers
    ax2.scatter(centers[:, 0], centers[:, 1], marker='o',
                c="white", alpha=1, s=200, edgecolor='k')

    for i, c in enumerate(centers):
        ax2.scatter(c[0], c[1], marker='$%d$' % i, alpha=1,
                    s=50, edgecolor='k')

    ax2.set_title("The visualization of the clustered data.")
    ax2.set_xlabel("Feature space for the 1st feature")
    ax2.set_ylabel("Feature space for the 2nd feature")

    plt.suptitle(("Silhouette analysis for KMeans clustering on sample data "
                  "with n_clusters = %d" % n_clusters),
                 fontsize=14, fontweight='bold')

plt.show()

